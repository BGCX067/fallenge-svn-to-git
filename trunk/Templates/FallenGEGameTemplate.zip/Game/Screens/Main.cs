﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

using FallenGE;
using FallenGE.Graphics;
using FallenGE.Game;
using FallenGE.Audio;
using FallenGE.Input;
using FallenGE.Win32;

namespace $safeprojectname$.Game.Screens
{
    public class MainScreen : Screen
    {
        public MainScreen(Engine engine) : base(engine) { }

        public override void Load()
        {
            nextScreen = "";
        }

        public override void Unload()
        {
            nextScreen = "";
        }

        public override void TransIn()
        {
        }

        public override void TransOut()
        {
        }

        public override void Render()
        {
            engine.RenderManager.Cls();

            engine.RenderManager.Flip();
        }

        public override void Update(float delta)
        {
            if (engine.KeyboardManager.KeyDown(System.Windows.Forms.Keys.Escape))
                Core.Quit();
        }
    }
}

