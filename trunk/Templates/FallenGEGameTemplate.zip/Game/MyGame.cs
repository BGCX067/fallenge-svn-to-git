﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using FallenGE.Game;

using $safeprojectname$.Game.Screens;

namespace $safeprojectname$.Game
{
    public class MyGame : GameManager
    {
        public override void Startup()
        {
            CreateEngine();

            // Add screens here
            AddScreen("Main", new MainScreen(engine));

            CreateGame("$safeprojectname$", "data/", 800, 600, true);

            engine.RenderManager.SetScale(1.0f, 1.0f);
        }

        public override void Shutdown()
        {
            DestroyEngine();
        }

        public override void Render()
        {
            if (currentScreen != null)
                currentScreen.Render();
        }

        public override void Update(float delta)
        {
            if (currentScreen != null)
                currentScreen.Update(delta);

            if (currentScreen.NextScreen != "")
                ChangeScreen(currentScreen.NextScreen);
        }
    }
}
